import sys

from PyQt5.QtWidgets import QApplication
"""
   行李分拣系统，运行main方法
"""
from UiMain import UI_Main

if __name__ == "__main__":
    try:
        app = QApplication(sys.argv)
        mainWindow =UI_Main()
        mainWindow.showMaximized()
        sys.exit(app.exec_())
    except Exception as E:
        print(E)
